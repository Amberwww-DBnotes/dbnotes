#!/bin/bash

# ----------------------------------------------------------------------------------------------
# NAME
#     Auto_Install_DM8_for_linux
# DESCRIPTION
#     AutoInstall_DM8, for Linux [Centos7.X && KylinV10 && openEuler24(X86_64/ARM64)]  
# AUTHOR
#     Written by AmberWu  @20251024  
#************* if you need any support,contact my wechat: sky_amber **************
# ----------------------------------------------------------------------------------------------

##Global environment variable 
#本安装脚本存放&&工作目录
work_dir=$(cd `dirname $0`;pwd) 

main() {
chmod -R +x ${work_dir}/DM8_x86_install
chmod -R +x ${work_dir}/DM8_arm_install

##add 20250718,判断架构为X86还是ARM环境.调用安装程序.
CPU=`arch` 
if [ "$CPU" = "x86_64" ]; then 
    ${work_dir}/DM8_x86_install
elif [ "$CPU" = "aarch64" ]; then 
    ${work_dir}/DM8_arm_install
else 
    echo "This System does not support deploying DM8. Please prepare X86_64/ARM environment before reinstalling. Now exiting... " 
    exit 1 
fi
echo
}

main

